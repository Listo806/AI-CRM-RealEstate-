(import the exact code I sent previously for AnalyticsCMA.jsx)
